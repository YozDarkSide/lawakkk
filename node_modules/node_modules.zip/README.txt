Move the "Node_modules" Folder to Your Folder Botz And PASTE AND OVERWRITE
نقل المجلد "Node_modules" إلى مجلد بوتز ولصق الكتابة فوق 
Mova a pasta "Node_modules" para o botz da pasta e a pasta e substitua